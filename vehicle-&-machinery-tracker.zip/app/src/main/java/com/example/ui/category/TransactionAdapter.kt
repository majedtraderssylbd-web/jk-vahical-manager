package com.example.ui.category

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.R
import com.example.data.model.Transaction
import com.example.databinding.ItemTransactionBinding
import com.example.util.LanguageManager

class TransactionAdapter(
    private val canEdit: Boolean,
    private val onDeleteClick: (Transaction) -> Unit
) : ListAdapter<Transaction, TransactionAdapter.TransactionViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val binding = ItemTransactionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TransactionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TransactionViewHolder(private val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Transaction) {
            val context = binding.root.context
            val isBn = LanguageManager.isBengali(context)

            val moduleTitle = LanguageManager.getModuleTitle(context, item.type)
            binding.tvTransTitle.text = moduleTitle
            binding.tvTransVehicle.text = item.vehicleName

            val isIncome = item.type == "daily_rent" || (item.type == "buy_sell" && item.amount >= 0)
            val prefix = if (isIncome) "+ ৳ " else "- ৳ "
            binding.tvTransAmount.text = "$prefix${item.amount.toInt()}"

            val amountColor = if (isIncome) {
                ContextCompat.getColor(context, R.color.status_approved)
            } else {
                ContextCompat.getColor(context, R.color.primary)
            }
            binding.tvTransAmount.setTextColor(amountColor)

            // Setup icon
            val iconRes = when (item.type) {
                "daily_rent" -> R.drawable.ic_rent
                "fuel_tracking" -> R.drawable.ic_fuel
                "driver_salary" -> R.drawable.ic_salary
                "maintenance_service" -> R.drawable.ic_maintenance
                else -> R.drawable.ic_buy_sell
            }
            binding.ivTransIcon.setImageResource(iconRes)

            // Details subtitle
            val sb = StringBuilder()
            if (item.date.isNotEmpty()) sb.append(item.date)
            if (item.driverName.isNotEmpty()) {
                val driverLabel = if (isBn) "ড্রাইভার: " else "Driver: "
                if (sb.isNotEmpty()) sb.append(" • ")
                sb.append("$driverLabel${item.driverName}")
            }
            if (item.fuelLiters > 0) {
                val literLabel = if (isBn) " লিটার" else " L"
                if (sb.isNotEmpty()) sb.append(" • ")
                sb.append("${item.fuelLiters}$literLabel")
            }
            if (item.rentDays > 1) {
                val daysLabel = if (isBn) " দিন" else " days"
                if (sb.isNotEmpty()) sb.append(" • ")
                sb.append("${item.rentDays}$daysLabel")
            }
            if (item.notes.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append("\n")
                sb.append(item.notes)
            }
            binding.tvTransDetails.text = sb.toString()

            if (canEdit) {
                binding.btnDeleteTrans.visibility = View.VISIBLE
                binding.btnDeleteTrans.setOnClickListener { onDeleteClick(item) }
            } else {
                binding.btnDeleteTrans.visibility = View.GONE
            }
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Transaction>() {
        override fun areItemsTheSame(oldItem: Transaction, newItem: Transaction): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Transaction, newItem: Transaction): Boolean = oldItem == newItem
    }
}
