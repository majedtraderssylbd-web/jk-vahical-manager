package com.example.ui.auth

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.lifecycleScope
import com.example.R
import com.example.data.firebase.FirestoreHelper
import com.example.data.model.User
import com.example.databinding.ActivitySignupBinding
import com.example.util.LanguageManager
import com.example.util.LocaleHelper
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var firestoreHelper: FirestoreHelper
    private lateinit var credentialManager: CredentialManager

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        firestoreHelper = FirestoreHelper.getInstance(this)
        credentialManager = CredentialManager.create(this)

        setupUI()
    }

    private fun setupUI() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        // Language Toggle in Toolbar
        binding.btnLanguageToggle.text = if (LanguageManager.isBengali(this)) "English" else "বাংলা"
        binding.btnLanguageToggle.setOnClickListener {
            LanguageManager.toggleLanguage(this)
        }

        binding.tvGoToLogin.setOnClickListener {
            finish()
        }

        binding.btnSubmitSignup.setOnClickListener {
            val name = binding.etFullName.text?.toString()?.trim() ?: ""
            val email = binding.etEmail.text?.toString()?.trim() ?: ""
            val password = binding.etPassword.text?.toString()?.trim() ?: ""

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                val msg = if (LanguageManager.isBengali(this)) "সকল তথ্য পূরণ করুন" else "Please fill all fields"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                signUpWithGoogleProvider(name)
            }
        }
    }

    private suspend fun signUpWithGoogleProvider(fullName: String) {
        try {
            val serverClientId = getString(R.string.default_web_client_id)
            val signInOption = GetSignInWithGoogleOption.Builder(serverClientId).build()
            val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

            val result = credentialManager.getCredential(this, request)
            val credential = result.credential

            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val firebaseCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)

                auth.signInWithCredential(firebaseCredential)
                    .addOnSuccessListener { authResult ->
                        val uid = authResult.user?.uid ?: ""
                        val userEmail = authResult.user?.email ?: ""
                        val dbId = getString(R.string.firestore_database_id)
                        val firestore = FirebaseFirestore.getInstance(dbId)

                        // Register as pending status for Admin Approval
                        val pendingUser = User(
                            uid = uid,
                            email = userEmail,
                            displayName = fullName.ifEmpty { authResult.user?.displayName ?: "User" },
                            role = "user",
                            status = "pending", // Set status to pending
                            createdAt = System.currentTimeMillis()
                        )

                        firestore.collection("users").document(uid).set(pendingUser.toMap())
                            .addOnSuccessListener {
                                showPendingApprovalDialog()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(this, "Registration error: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Sign up failed: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("SignupActivity", "Sign up was cancelled by user: ${e.message}")
        } catch (e: Exception) {
            Log.e("SignupActivity", "Sign up error", e)
            Toast.makeText(this, "Sign up error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPendingApprovalDialog() {
        val isBn = LanguageManager.isBengali(this)
        val title = if (isBn) "আবেদন জমা হয়েছে" else "Account Submitted"
        val message = if (isBn) {
            "আপনার একাউন্টটি অ্যাডমিন অনুমোদনের জন্য অপেক্ষারত রয়েছে। অনুমোদিত না হওয়া পর্যন্ত আপনি গেস্ট হিসেবে ডেটা দেখতে পারবেন কিন্তু পরিবর্তন করতে পারবেন না।"
        } else {
            "Your account registration has been submitted. Status is 'pending'. You can browse data in read-only mode, and will have editing permissions once approved by an Admin."
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (isBn) "ঠিক আছে" else "Got it") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }
}
