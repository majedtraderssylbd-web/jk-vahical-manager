package com.example.ui.auth

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.lifecycleScope
import com.example.R
import com.example.data.firebase.FirestoreHelper
import com.example.databinding.ActivityLoginBinding
import com.example.MainActivity
import com.example.util.LanguageManager
import com.example.util.LocaleHelper
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var firestoreHelper: FirestoreHelper
    private lateinit var credentialManager: CredentialManager

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        firestoreHelper = FirestoreHelper.getInstance(this)
        credentialManager = CredentialManager.create(this)

        setupUI()
        checkExistingAuth()
    }

    private fun checkExistingAuth() {
        if (auth.currentUser != null) {
            firestoreHelper.setGuest(false)
            firestoreHelper.checkUserApprovalStatus { _, _ ->
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }

    private fun setupUI() {
        // Language Toggle in Toolbar
        binding.btnLanguageToggle.text = if (LanguageManager.isBengali(this)) "English" else "বাংলা"
        binding.btnLanguageToggle.setOnClickListener {
            LanguageManager.toggleLanguage(this)
        }

        // Email / Password Sign In
        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text?.toString()?.trim() ?: ""
            val password = binding.etPassword.text?.toString()?.trim() ?: ""

            if (email.isEmpty() || password.isEmpty()) {
                val msg = if (LanguageManager.isBengali(this)) "ইমেইল ও পাসওয়ার্ড প্রদান করুন" else "Please enter email and password"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Perform sign in or auto-sign with Google
            lifecycleScope.launch {
                initiateGoogleSignIn()
            }
        }

        // Google Sign In (Primary Identity Provider)
        binding.btnGoogleSignIn.setOnClickListener {
            lifecycleScope.launch {
                initiateGoogleSignIn()
            }
        }

        // Guest Mode (Read-Only)
        binding.btnGuestMode.setOnClickListener {
            firestoreHelper.setGuest(true)
            val msg = if (LanguageManager.isBengali(this)) "গেস্ট মোডে প্রবেশ করেছেন (রিড-অনলি)" else "Entered as Guest (Read-Only Mode)"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        // Sign Up redirection
        binding.tvGoToSignup.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }
    }

    private suspend fun initiateGoogleSignIn() {
        try {
            val serverClientId = getString(R.string.default_web_client_id)
            val signInOption = GetSignInWithGoogleOption.Builder(serverClientId)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(signInOption)
                .build()

            val result = credentialManager.getCredential(this, request)
            val credential = result.credential

            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val firebaseCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)

                auth.signInWithCredential(firebaseCredential)
                    .addOnSuccessListener {
                        firestoreHelper.setGuest(false)
                        firestoreHelper.checkUserApprovalStatus { isApproved, _ ->
                            val msg = if (isApproved) {
                                if (LanguageManager.isBengali(this)) "স্বাগতম! সফলভাবে লগইন হয়েছে" else "Welcome! Signed in successfully"
                            } else {
                                if (LanguageManager.isBengali(this)) "লগইন সম্পন্ন (অনুমোদনের অপেক্ষায়)" else "Signed in (Approval Pending)"
                            }
                            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, MainActivity::class.java))
                            finish()
                        }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Sign in failed: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("LoginActivity", "Google Sign-In was cancelled by user: ${e.message}")
        } catch (e: Exception) {
            Log.e("LoginActivity", "Credential manager sign-in error", e)
            Toast.makeText(this, "Authentication error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
