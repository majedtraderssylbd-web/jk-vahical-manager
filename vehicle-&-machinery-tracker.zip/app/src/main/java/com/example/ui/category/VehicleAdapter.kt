package com.example.ui.category

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.R
import com.example.data.model.Vehicle
import com.example.databinding.ItemVehicleBinding
import com.example.util.LanguageManager

class VehicleAdapter(
    private val canEdit: Boolean,
    private val onDeleteClick: (Vehicle) -> Unit
) : ListAdapter<Vehicle, VehicleAdapter.VehicleViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VehicleViewHolder {
        val binding = ItemVehicleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VehicleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VehicleViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class VehicleViewHolder(private val binding: ItemVehicleBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(vehicle: Vehicle) {
            val context = binding.root.context
            binding.tvVehicleName.text = vehicle.name
            binding.tvRegNumber.text = "Reg: ${vehicle.registrationNumber} • ${vehicle.modelYear}"

            val statusText = LanguageManager.getStatusTitle(context, vehicle.status)
            binding.tvStatusBadge.text = statusText

            val statusBgColor = when (vehicle.status.lowercase()) {
                "available" -> ContextCompat.getColor(context, R.color.status_approved)
                "rented" -> ContextCompat.getColor(context, R.color.status_rented)
                "under_maintenance" -> ContextCompat.getColor(context, R.color.status_maintenance)
                else -> ContextCompat.getColor(context, R.color.primary)
            }
            binding.tvStatusBadge.backgroundTintList = ContextCompat.getColorStateList(context, statusBgColor)

            val rateLabel = if (LanguageManager.isBengali(context)) "দৈনিক ভাড়া: ৳" else "Daily Rent: ৳"
            binding.tvDailyRate.text = "$rateLabel ${vehicle.dailyRentRate.toInt()} / day"

            if (vehicle.notes.isNotEmpty()) {
                binding.tvNotes.visibility = View.VISIBLE
                binding.tvNotes.text = vehicle.notes
            } else {
                binding.tvNotes.visibility = View.GONE
            }

            if (canEdit) {
                binding.btnDeleteVehicle.visibility = View.VISIBLE
                binding.btnDeleteVehicle.setOnClickListener { onDeleteClick(vehicle) }
            } else {
                binding.btnDeleteVehicle.visibility = View.GONE
            }
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Vehicle>() {
        override fun areItemsTheSame(oldItem: Vehicle, newItem: Vehicle): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Vehicle, newItem: Vehicle): Boolean = oldItem == newItem
    }
}
