package com.example.ui.category

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.R
import com.example.data.firebase.FirestoreHelper
import com.example.data.model.Transaction
import com.example.data.model.Vehicle
import com.example.databinding.ActivityCategoryDetailBinding
import com.example.databinding.DialogAddTransactionBinding
import com.example.databinding.DialogAddVehicleBinding
import com.example.util.LanguageManager
import com.example.util.LocaleHelper
import com.google.firebase.firestore.ListenerRegistration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class CategoryDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCategoryDetailBinding
    private lateinit var firestoreHelper: FirestoreHelper

    private var categoryKey: String = "cng"
    private var selectedModule: String = "fleet" // "fleet", "daily_rent", "fuel_tracking", "driver_salary", "maintenance_service", "buy_sell"

    private var vehiclesList = listOf<Vehicle>()
    private var transactionsList = listOf<Transaction>()

    private lateinit var vehicleAdapter: VehicleAdapter
    private lateinit var transactionAdapter: TransactionAdapter

    private var vehicleListener: ListenerRegistration? = null
    private var transactionListener: ListenerRegistration? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCategoryDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firestoreHelper = FirestoreHelper.getInstance(this)
        categoryKey = intent.getStringExtra(EXTRA_CATEGORY) ?: "cng"

        setupToolbar()
        setupAdapters()
        setupChips()
        setupAccessControl()
        observeData()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.detailToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.detailToolbar.setNavigationOnClickListener { finish() }

        val categoryTitle = LanguageManager.getCategoryTitle(this, categoryKey)
        supportActionBar?.title = categoryTitle

        val isBn = LanguageManager.isBengali(this)
        binding.btnDetailLangToggle.text = if (isBn) "English" else "বাংলা"
        binding.btnDetailLangToggle.setOnClickListener {
            LanguageManager.toggleLanguage(this)
        }
    }

    private fun setupAccessControl() {
        val canEdit = firestoreHelper.canEdit()
        if (!canEdit) {
            binding.fabAdd.visibility = View.GONE
            binding.tvGuestNotice.visibility = View.VISIBLE
            binding.tvGuestNotice.text = if (firestoreHelper.isGuestMode) {
                getString(R.string.guest_banner_text)
            } else {
                getString(R.string.pending_banner_text)
            }
        } else {
            binding.fabAdd.visibility = View.VISIBLE
            binding.tvGuestNotice.visibility = View.GONE
        }
    }

    private fun setupAdapters() {
        val canEdit = firestoreHelper.canEdit()

        vehicleAdapter = VehicleAdapter(canEdit) { vehicle ->
            confirmDeleteVehicle(vehicle)
        }

        transactionAdapter = TransactionAdapter(canEdit) { trans ->
            confirmDeleteTransaction(trans)
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = vehicleAdapter

        binding.fabAdd.setOnClickListener {
            if (selectedModule == "fleet") {
                showAddVehicleDialog()
            } else {
                showAddTransactionDialog(selectedModule)
            }
        }
    }

    private fun setupChips() {
        val isBn = LanguageManager.isBengali(this)

        binding.chipFleet.text = if (isBn) "যানবাহন ফ্লিট" else "Fleet Units"
        binding.chipRent.text = LanguageManager.getModuleTitle(this, "daily_rent")
        binding.chipFuel.text = LanguageManager.getModuleTitle(this, "fuel_tracking")
        binding.chipSalary.text = LanguageManager.getModuleTitle(this, "driver_salary")
        binding.chipMaintenance.text = LanguageManager.getModuleTitle(this, "maintenance_service")
        binding.chipBuySell.text = LanguageManager.getModuleTitle(this, "buy_sell")

        binding.chipGroupModules.setOnCheckedStateChangeListener { _, checkedIds ->
            val checkedId = checkedIds.firstOrNull() ?: R.id.chipFleet
            selectedModule = when (checkedId) {
                R.id.chipFleet -> "fleet"
                R.id.chipRent -> "daily_rent"
                R.id.chipFuel -> "fuel_tracking"
                R.id.chipSalary -> "driver_salary"
                R.id.chipMaintenance -> "maintenance_service"
                R.id.chipBuySell -> "buy_sell"
                else -> "fleet"
            }
            updateViewForModule()
        }
    }

    private fun updateViewForModule() {
        val isBn = LanguageManager.isBengali(this)
        if (selectedModule == "fleet") {
            binding.recyclerView.adapter = vehicleAdapter
            binding.fabAdd.text = if (isBn) "নতুন মেশিন যোগ করুন" else getString(R.string.add_vehicle)
            filterAndDisplayVehicles()
        } else {
            binding.recyclerView.adapter = transactionAdapter
            val moduleTitle = LanguageManager.getModuleTitle(this, selectedModule)
            binding.fabAdd.text = if (isBn) "+ হিসাব এন্ট্রি ($moduleTitle)" else "+ Add $moduleTitle"
            filterAndDisplayTransactions()
        }
    }

    private fun observeData() {
        // Listen to vehicles
        vehicleListener = firestoreHelper.listenVehicles(categoryKey) { list ->
            vehiclesList = list
            if (selectedModule == "fleet") {
                filterAndDisplayVehicles()
            }
            updateKpiStats()
        }

        // Listen to transactions
        transactionListener = firestoreHelper.listenTransactions(categoryKey, null) { list ->
            transactionsList = list
            if (selectedModule != "fleet") {
                filterAndDisplayTransactions()
            }
            updateKpiStats()
        }
    }

    private fun filterAndDisplayVehicles() {
        vehicleAdapter.submitList(vehiclesList)
        binding.layoutEmptyState.visibility = if (vehiclesList.isEmpty()) View.VISIBLE else View.GONE
        binding.recyclerView.visibility = if (vehiclesList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun filterAndDisplayTransactions() {
        val filtered = transactionsList.filter { it.type == selectedModule }
        transactionAdapter.submitList(filtered)
        binding.layoutEmptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
        binding.recyclerView.visibility = if (filtered.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun updateKpiStats() {
        val isBn = LanguageManager.isBengali(this)
        val unitsSuffix = if (isBn) " টি" else " Units"

        binding.tvStat1Val.text = "${vehiclesList.size}$unitsSuffix"
        binding.tvStat1Label.text = if (isBn) "মোট ইউনিট" else "Total Units"

        var catRevenue = 0.0
        var catExpense = 0.0

        for (t in transactionsList) {
            if (t.type == "daily_rent" || (t.type == "buy_sell" && t.amount >= 0)) {
                catRevenue += t.amount
            } else {
                catExpense += t.amount
            }
        }

        binding.tvStat2Val.text = "৳ ${catRevenue.toInt()}"
        binding.tvStat3Val.text = "৳ ${catExpense.toInt()}"
    }

    private fun showAddVehicleDialog() {
        val dialogBinding = DialogAddVehicleBinding.inflate(LayoutInflater.from(this))
        val isBn = LanguageManager.isBengali(this)

        val statusKeys = listOf("available", "rented", "under_maintenance", "sold")
        val statusLabels = statusKeys.map { LanguageManager.getStatusTitle(this, it) }
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statusLabels)
        dialogBinding.spVehicleStatus.adapter = spinnerAdapter

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton(if (isBn) "সংরক্ষণ" else "Save") { _, _ ->
                val name = dialogBinding.etVehicleName.text?.toString()?.trim() ?: ""
                val regNumber = dialogBinding.etRegNumber.text?.toString()?.trim() ?: ""
                val modelYear = dialogBinding.etModelYear.text?.toString()?.trim() ?: ""
                val rentRate = dialogBinding.etDailyRentRate.text?.toString()?.toDoubleOrNull() ?: 0.0
                val purchasePrice = dialogBinding.etPurchasePrice.text?.toString()?.toDoubleOrNull() ?: 0.0
                val selectedStatus = statusKeys.getOrElse(dialogBinding.spVehicleStatus.selectedItemPosition) { "available" }
                val notes = dialogBinding.etNotes.text?.toString()?.trim() ?: ""

                if (name.isEmpty() || regNumber.isEmpty()) {
                    Toast.makeText(this, if (isBn) "নাম ও রেজিস্ট্রেশন নম্বর আবশ্যক" else "Name & Reg Number are required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val vehicle = Vehicle(
                    id = "veh-${UUID.randomUUID()}",
                    name = name,
                    category = categoryKey,
                    registrationNumber = regNumber,
                    modelYear = modelYear,
                    status = selectedStatus,
                    purchasePrice = purchasePrice,
                    dailyRentRate = rentRate,
                    notes = notes,
                    updatedAt = System.currentTimeMillis()
                )

                firestoreHelper.saveVehicle(vehicle) { success, err ->
                    if (success) {
                        Toast.makeText(this, if (isBn) "যানবাহন সংরক্ষিত হয়েছে" else "Vehicle saved", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Error: $err", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(if (isBn) "বাতিল" else "Cancel", null)
            .show()
    }

    private fun showAddTransactionDialog(presetType: String) {
        val dialogBinding = DialogAddTransactionBinding.inflate(LayoutInflater.from(this))
        val isBn = LanguageManager.isBengali(this)

        val typeKeys = listOf("daily_rent", "fuel_tracking", "driver_salary", "maintenance_service", "buy_sell")
        val typeLabels = typeKeys.map { LanguageManager.getModuleTitle(this, it) }
        val typeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, typeLabels)
        dialogBinding.spTransType.adapter = typeAdapter

        val presetIndex = typeKeys.indexOf(presetType).coerceAtLeast(0)
        dialogBinding.spTransType.setSelection(presetIndex)

        val vehicleNames = vehiclesList.map { "${it.name} (${it.registrationNumber})" }
        val vAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, vehicleNames)
        dialogBinding.spVehicleSelect.adapter = vAdapter

        val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton(if (isBn) "সংরক্ষণ" else "Save") { _, _ ->
                val amount = dialogBinding.etTransAmount.text?.toString()?.toDoubleOrNull() ?: 0.0
                if (amount <= 0.0) {
                    Toast.makeText(this, if (isBn) "টাকার পরিমাণ আবশ্যক" else "Amount is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val selectedType = typeKeys.getOrElse(dialogBinding.spTransType.selectedItemPosition) { "daily_rent" }
                val selectedVehicle = vehiclesList.getOrNull(dialogBinding.spVehicleSelect.selectedItemPosition)
                val vehicleId = selectedVehicle?.id ?: "general"
                val vehicleName = selectedVehicle?.name ?: "Fleet Unit"

                val driver = dialogBinding.etDriverName.text?.toString()?.trim() ?: ""
                val fuelLiters = dialogBinding.etFuelLiters.text?.toString()?.toDoubleOrNull() ?: 0.0
                val rentDays = dialogBinding.etRentDays.text?.toString()?.toIntOrNull() ?: 1
                val notes = dialogBinding.etTransNotes.text?.toString()?.trim() ?: ""

                val transaction = Transaction(
                    id = "trans-${UUID.randomUUID()}",
                    vehicleId = vehicleId,
                    vehicleName = vehicleName,
                    category = categoryKey,
                    type = selectedType,
                    amount = amount,
                    date = todayDate,
                    notes = notes,
                    driverName = driver,
                    fuelLiters = fuelLiters,
                    rentDays = rentDays,
                    recordedBy = firestoreHelper.currentUserProfile?.displayName ?: "Manager",
                    createdAt = System.currentTimeMillis()
                )

                firestoreHelper.saveTransaction(transaction) { success, err ->
                    if (success) {
                        Toast.makeText(this, if (isBn) "হিসাব সংরক্ষিত হয়েছে" else "Transaction recorded", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Error: $err", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(if (isBn) "বাতিল" else "Cancel", null)
            .show()
    }

    private fun confirmDeleteVehicle(vehicle: Vehicle) {
        val isBn = LanguageManager.isBengali(this)
        AlertDialog.Builder(this)
            .setTitle(if (isBn) "মুছে ফেলুন" else "Delete Vehicle")
            .setMessage(if (isBn) "${vehicle.name} অপসারণ করতে চান?" else "Delete ${vehicle.name} from fleet?")
            .setPositiveButton(if (isBn) "হ্যাঁ" else "Delete") { _, _ ->
                firestoreHelper.deleteVehicle(vehicle.id) { success, err ->
                    if (success) {
                        Toast.makeText(this, if (isBn) "অপসারণ সম্পন্ন" else "Vehicle deleted", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Error: $err", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(if (isBn) "না" else "Cancel", null)
            .show()
    }

    private fun confirmDeleteTransaction(trans: Transaction) {
        val isBn = LanguageManager.isBengali(this)
        AlertDialog.Builder(this)
            .setTitle(if (isBn) "মুছে ফেলুন" else "Delete Record")
            .setMessage(if (isBn) "এই লেনদেনটি মুছে ফেলতে চান?" else "Delete this financial record?")
            .setPositiveButton(if (isBn) "হ্যাঁ" else "Delete") { _, _ ->
                firestoreHelper.deleteTransaction(trans.id) { success, err ->
                    if (success) {
                        Toast.makeText(this, if (isBn) "মুছে ফেলা হয়েছে" else "Record deleted", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Error: $err", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(if (isBn) "না" else "Cancel", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        vehicleListener?.remove()
        transactionListener?.remove()
    }

    companion object {
        const val EXTRA_CATEGORY = "extra_category"
    }
}
