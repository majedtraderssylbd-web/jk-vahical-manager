package com.example.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.os.Build
import java.util.Locale

object LanguageManager {
    private const val PREFS_NAME = "vehicle_app_prefs"
    private const val KEY_LANGUAGE = "selected_language"

    const val LANG_EN = "en"
    const val LANG_BN = "bn"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getLanguage(context: Context): String {
        return getPrefs(context).getString(KEY_LANGUAGE, LANG_EN) ?: LANG_EN
    }

    fun setLanguage(context: Context, langCode: String) {
        getPrefs(context).edit().putString(KEY_LANGUAGE, langCode).apply()
    }

    fun isBengali(context: Context): Boolean {
        return getLanguage(context) == LANG_BN
    }

    fun toggleLanguage(activity: Activity) {
        val currentLang = getLanguage(activity)
        val newLang = if (currentLang == LANG_EN) LANG_BN else LANG_EN
        setLanguage(activity, newLang)
        applyLocale(activity)
        activity.recreate()
    }

    fun applyLocale(context: Context): Context {
        val lang = getLanguage(context)
        val locale = Locale(lang)
        Locale.setDefault(locale)

        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            context.createConfigurationContext(config)
        } else {
            @Suppress("DEPRECATION")
            context.resources.updateConfiguration(config, context.resources.displayMetrics)
            context
        }
    }

    fun getCategoryTitle(context: Context, category: String): String {
        val isBn = isBengali(context)
        return when (category) {
            "cng" -> if (isBn) "সিএনজি অটোরিকশা" else "CNG Auto"
            "car_microbus" -> if (isBn) "কার ও মাইক্রোবাস" else "Car & Microbus"
            "truck" -> if (isBn) "ট্রাক ও পিকআপ" else "Truck & Pickup"
            "other_machinery" -> if (isBn) "ভারী যন্ত্রপাতি ও অন্যান্য (ট্রাক্টর, জেসিবি)" else "Machinery & Heavy Units (Tractor, JCB)"
            else -> category
        }
    }

    fun getModuleTitle(context: Context, module: String): String {
        val isBn = isBengali(context)
        return when (module) {
            "buy_sell" -> if (isBn) "ক্রয় / বিক্রয়" else "Buy & Sell"
            "daily_rent" -> if (isBn) "দৈনিক ভাড়া সংগ্রহ" else "Daily Rent Collection"
            "driver_salary" -> if (isBn) "ড্রাইভারের বেতন" else "Driver Salary"
            "maintenance_service" -> if (isBn) "সার্ভিস ও মেরামত" else "Maintenance & Service"
            "fuel_tracking" -> if (isBn) "জ্বালানী খরচ ট্র্যাকিং" else "Fuel Tracking"
            else -> module
        }
    }

    fun getStatusTitle(context: Context, status: String): String {
        val isBn = isBengali(context)
        return when (status) {
            "available" -> if (isBn) "উপলব্ধ (ফ্রি)" else "Available"
            "rented" -> if (isBn) "ভাড়ায় চলছে" else "Rented Out"
            "under_maintenance" -> if (isBn) "মেরামতাধীন" else "Under Maintenance"
            "sold" -> if (isBn) "বিক্রি সম্পন্ন" else "Sold"
            "approved" -> if (isBn) "অনুমোদিত" else "Approved"
            "pending" -> if (isBn) "অনুমোদনের অপেক্ষায়" else "Pending Approval"
            else -> status
        }
    }
}
