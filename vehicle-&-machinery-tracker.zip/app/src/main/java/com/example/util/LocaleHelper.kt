package com.example.util

import android.content.Context

object LocaleHelper {
    fun onAttach(context: Context): Context {
        return LanguageManager.applyLocale(context)
    }

    fun setLocale(context: Context, language: String): Context {
        LanguageManager.setLanguage(context, language)
        return LanguageManager.applyLocale(context)
    }

    fun getLanguage(context: Context): String {
        return LanguageManager.getLanguage(context)
    }
}
