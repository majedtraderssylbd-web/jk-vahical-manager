package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.data.firebase.FirestoreHelper
import com.example.data.model.Transaction
import com.example.data.model.Vehicle
import com.example.databinding.ActivityMainBinding
import com.example.ui.auth.LoginActivity
import com.example.ui.category.CategoryDetailActivity
import com.example.util.LanguageManager
import com.example.util.LocaleHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ListenerRegistration

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var firestoreHelper: FirestoreHelper
    private val listeners = mutableListOf<ListenerRegistration>()

    private var allVehicles = listOf<Vehicle>()
    private var allTransactions = listOf<Transaction>()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firestoreHelper = FirestoreHelper.getInstance(this)

        // Route to Login if neither authenticated nor guest
        if (FirebaseAuth.getInstance().currentUser == null && !firestoreHelper.isGuestMode) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setupToolbar()
        setupCategoryCards()
        setupStatusBanner()
        observeFleetAndFinancials()
    }

    override fun onResume() {
        super.onResume()
        setupStatusBanner()
    }

    private fun setupToolbar() {
        val isBn = LanguageManager.isBengali(this)
        binding.mainToolbar.title = getString(R.string.dashboard_title)
        binding.btnMainLangToggle.text = if (isBn) "English" else "বাংলা"
        binding.btnMainLangToggle.setOnClickListener {
            LanguageManager.toggleLanguage(this)
        }

        binding.btnSignOut.setOnClickListener {
            showSignOutDialog()
        }
    }

    private fun setupStatusBanner() {
        val isBn = LanguageManager.isBengali(this)
        if (firestoreHelper.isGuestMode) {
            binding.cardStatusBanner.setCardBackgroundColor(ContextCompat.getColor(this, R.color.primary_container))
            binding.tvBannerTitle.text = if (isBn) "গেস্ট মোড (রিড-অনলি)" else "Guest Mode (Read-Only)"
            binding.tvBannerTitle.setTextColor(ContextCompat.getColor(this, R.color.primary_dark))
            binding.tvBannerMessage.text = getString(R.string.guest_banner_text)
            binding.cardStatusBanner.visibility = View.VISIBLE
        } else {
            val user = firestoreHelper.currentUserProfile
            if (user != null) {
                if (user.isApproved()) {
                    binding.cardStatusBanner.setCardBackgroundColor(ContextCompat.getColor(this, R.color.surface))
                    val roleLabel = if (user.isAdmin()) (if (isBn) "এডমিন" else "Admin") else (if (isBn) "অনুমোদিত ম্যানেজার" else "Approved Manager")
                    binding.tvBannerTitle.text = "${user.displayName.ifEmpty { "User" }} ($roleLabel)"
                    binding.tvBannerTitle.setTextColor(ContextCompat.getColor(this, R.color.status_approved))
                    binding.tvBannerMessage.text = if (isBn) "পূর্ণ অ্যাক্সেস চালু রয়েছে (যোগ, পরিবর্তন ও অপসারণ অনুমোদিত)" else "Full access active (Add, Edit, Delete permitted)"
                    binding.cardStatusBanner.visibility = View.VISIBLE
                } else {
                    binding.cardStatusBanner.setCardBackgroundColor(ContextCompat.getColor(this, R.color.primary_container))
                    binding.tvBannerTitle.text = if (isBn) "অনুমোদনের অপেক্ষায়" else "Pending Admin Approval"
                    binding.tvBannerTitle.setTextColor(ContextCompat.getColor(this, R.color.status_pending))
                    binding.tvBannerMessage.text = getString(R.string.pending_banner_text)
                    binding.cardStatusBanner.visibility = View.VISIBLE
                }
            } else {
                binding.cardStatusBanner.visibility = View.GONE
            }
        }
    }

    private fun setupCategoryCards() {
        val isBn = LanguageManager.isBengali(this)

        // 1. CNG
        binding.tvCngTitle.text = LanguageManager.getCategoryTitle(this, "cng")
        binding.cardCng.setOnClickListener {
            openCategoryDetail("cng")
        }

        // 2. Car & Microbus
        binding.tvCarTitle.text = LanguageManager.getCategoryTitle(this, "car_microbus")
        binding.cardCar.setOnClickListener {
            openCategoryDetail("car_microbus")
        }

        // 3. Truck
        binding.tvTruckTitle.text = LanguageManager.getCategoryTitle(this, "truck")
        binding.cardTruck.setOnClickListener {
            openCategoryDetail("truck")
        }

        // 4. Other Vehicles & Machinery (JCB, Tractor, Troller, Trole, etc.)
        binding.tvMachineryTitle.text = LanguageManager.getCategoryTitle(this, "other_machinery")
        binding.cardMachinery.setOnClickListener {
            openCategoryDetail("other_machinery")
        }
    }

    private fun openCategoryDetail(categoryKey: String) {
        val intent = Intent(this, CategoryDetailActivity::class.java).apply {
            putExtra(CategoryDetailActivity.EXTRA_CATEGORY, categoryKey)
        }
        startActivity(intent)
    }

    private fun observeFleetAndFinancials() {
        val categories = listOf("cng", "car_microbus", "truck", "other_machinery")

        // Seed initial mock items if collection is empty
        for (cat in categories) {
            firestoreHelper.seedDefaultVehiclesIfEmpty(cat)
        }

        val allVehiclesMap = mutableMapOf<String, List<Vehicle>>()
        val allTransMap = mutableMapOf<String, List<Transaction>>()

        for (cat in categories) {
            val vListener = firestoreHelper.listenVehicles(cat) { list ->
                allVehiclesMap[cat] = list
                updateDashboard(allVehiclesMap, allTransMap)
            }
            listeners.add(vListener)

            val tListener = firestoreHelper.listenTransactions(cat, null) { list ->
                allTransMap[cat] = list
                updateDashboard(allVehiclesMap, allTransMap)
            }
            listeners.add(tListener)
        }
    }

    private fun updateDashboard(
        vehiclesMap: Map<String, List<Vehicle>>,
        transMap: Map<String, List<Transaction>>
    ) {
        val isBn = LanguageManager.isBengali(this)
        val unitsSuffix = if (isBn) " টি" else " Units"

        val cngList = vehiclesMap["cng"] ?: emptyList()
        val carList = vehiclesMap["car_microbus"] ?: emptyList()
        val truckList = vehiclesMap["truck"] ?: emptyList()
        val machList = vehiclesMap["other_machinery"] ?: emptyList()

        binding.badgeCngCount.text = "${cngList.size}$unitsSuffix"
        binding.badgeCarCount.text = "${carList.size}$unitsSuffix"
        binding.badgeTruckCount.text = "${truckList.size}$unitsSuffix"
        binding.badgeMachineryCount.text = "${machList.size}$unitsSuffix"

        val totalUnits = cngList.size + carList.size + truckList.size + machList.size
        binding.tvFleetCount.text = "$totalUnits"

        var totalRev = 0.0
        var totalExp = 0.0

        for ((_, tList) in transMap) {
            for (t in tList) {
                if (t.type == "daily_rent" || (t.type == "buy_sell" && t.amount >= 0)) {
                    totalRev += t.amount
                } else {
                    totalExp += t.amount
                }
            }
        }

        binding.tvTotalRevenue.text = "৳ ${totalRev.toInt()}"
        binding.tvTotalExpense.text = "৳ ${totalExp.toInt()}"
    }

    private fun showSignOutDialog() {
        val isBn = LanguageManager.isBengali(this)
        val title = if (isBn) "লগআউট" else "Sign Out"
        val message = if (isBn) "আপনি কি নিশ্চিতভাবে প্রস্থান করতে চান?" else "Are you sure you want to sign out?"

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (isBn) "হ্যাঁ" else "Yes") { _, _ ->
                FirebaseAuth.getInstance().signOut()
                firestoreHelper.setGuest(false)
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton(if (isBn) "না" else "Cancel", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        for (l in listeners) {
            l.remove()
        }
        listeners.clear()
    }
}
