package com.example.data.model

data class User(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val role: String = "user", // "admin" or "user"
    val status: String = "pending", // "pending" or "approved"
    val createdAt: Long = System.currentTimeMillis()
) {
    fun isApproved(): Boolean = status.equals("approved", ignoreCase = true)
    fun isAdmin(): Boolean = role.equals("admin", ignoreCase = true)

    fun toMap(): Map<String, Any?> {
        return mapOf(
            "uid" to uid,
            "email" to email,
            "displayName" to displayName,
            "role" to role,
            "status" to status,
            "createdAt" to createdAt
        )
    }

    companion object {
        fun fromMap(map: Map<String, Any?>): User {
            return User(
                uid = map["uid"] as? String ?: "",
                email = map["email"] as? String ?: "",
                displayName = map["displayName"] as? String ?: "",
                role = map["role"] as? String ?: "user",
                status = map["status"] as? String ?: "pending",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
