package com.example.data.model

data class Vehicle(
    val id: String = "",
    val name: String = "",
    val category: String = "cng", // "cng", "car_microbus", "truck", "other_machinery"
    val registrationNumber: String = "",
    val modelYear: String = "",
    val status: String = "available", // "available", "rented", "under_maintenance", "sold"
    val purchasePrice: Double = 0.0,
    val dailyRentRate: Double = 0.0,
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "name" to name,
            "category" to category,
            "registrationNumber" to registrationNumber,
            "modelYear" to modelYear,
            "status" to status,
            "purchasePrice" to purchasePrice,
            "dailyRentRate" to dailyRentRate,
            "notes" to notes,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromMap(map: Map<String, Any?>): Vehicle {
            return Vehicle(
                id = map["id"] as? String ?: "",
                name = map["name"] as? String ?: "",
                category = map["category"] as? String ?: "cng",
                registrationNumber = map["registrationNumber"] as? String ?: "",
                modelYear = map["modelYear"] as? String ?: "",
                status = map["status"] as? String ?: "available",
                purchasePrice = (map["purchasePrice"] as? Number)?.toDouble() ?: 0.0,
                dailyRentRate = (map["dailyRentRate"] as? Number)?.toDouble() ?: 0.0,
                notes = map["notes"] as? String ?: "",
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
