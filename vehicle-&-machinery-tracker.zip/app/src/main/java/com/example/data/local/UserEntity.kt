package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.User

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val uid: String,
    val email: String,
    val displayName: String,
    val role: String,
    val status: String,
    val createdAt: Long
) {
    fun toUser(): User = User(
        uid = uid,
        email = email,
        displayName = displayName,
        role = role,
        status = status,
        createdAt = createdAt
    )

    companion object {
        fun fromUser(u: User): UserEntity = UserEntity(
            uid = u.uid,
            email = u.email,
            displayName = u.displayName,
            role = u.role,
            status = u.status,
            createdAt = u.createdAt
        )
    }
}
