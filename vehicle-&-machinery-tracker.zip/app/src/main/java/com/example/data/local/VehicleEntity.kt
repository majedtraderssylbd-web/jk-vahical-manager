package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.Vehicle

@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val registrationNumber: String,
    val modelYear: String,
    val status: String,
    val purchasePrice: Double,
    val dailyRentRate: Double,
    val notes: String,
    val updatedAt: Long
) {
    fun toVehicle(): Vehicle = Vehicle(
        id = id,
        name = name,
        category = category,
        registrationNumber = registrationNumber,
        modelYear = modelYear,
        status = status,
        purchasePrice = purchasePrice,
        dailyRentRate = dailyRentRate,
        notes = notes,
        updatedAt = updatedAt
    )

    companion object {
        fun fromVehicle(v: Vehicle): VehicleEntity = VehicleEntity(
            id = v.id,
            name = v.name,
            category = v.category,
            registrationNumber = v.registrationNumber,
            modelYear = v.modelYear,
            status = v.status,
            purchasePrice = v.purchasePrice,
            dailyRentRate = v.dailyRentRate,
            notes = v.notes,
            updatedAt = v.updatedAt
        )
    }
}
