package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.Transaction

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val vehicleId: String,
    val vehicleName: String,
    val category: String,
    val type: String,
    val amount: Double,
    val date: String,
    val notes: String,
    val driverName: String,
    val fuelLiters: Double,
    val rentDays: Int,
    val recordedBy: String,
    val createdAt: Long
) {
    fun toTransaction(): Transaction = Transaction(
        id = id,
        vehicleId = vehicleId,
        vehicleName = vehicleName,
        category = category,
        type = type,
        amount = amount,
        date = date,
        notes = notes,
        driverName = driverName,
        fuelLiters = fuelLiters,
        rentDays = rentDays,
        recordedBy = recordedBy,
        createdAt = createdAt
    )

    companion object {
        fun fromTransaction(t: Transaction): TransactionEntity = TransactionEntity(
            id = t.id,
            vehicleId = t.vehicleId,
            vehicleName = t.vehicleName,
            category = t.category,
            type = t.type,
            amount = t.amount,
            date = t.date,
            notes = t.notes,
            driverName = t.driverName,
            fuelLiters = t.fuelLiters,
            rentDays = t.rentDays,
            recordedBy = t.recordedBy,
            createdAt = t.createdAt
        )
    }
}
