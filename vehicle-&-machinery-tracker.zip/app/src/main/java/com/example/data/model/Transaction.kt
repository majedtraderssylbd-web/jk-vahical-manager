package com.example.data.model

data class Transaction(
    val id: String = "",
    val vehicleId: String = "",
    val vehicleName: String = "",
    val category: String = "cng", // "cng", "car_microbus", "truck", "other_machinery"
    val type: String = "daily_rent", // "buy_sell", "daily_rent", "driver_salary", "maintenance_service", "fuel_tracking"
    val amount: Double = 0.0,
    val date: String = "",
    val notes: String = "",
    val driverName: String = "",
    val fuelLiters: Double = 0.0,
    val rentDays: Int = 1,
    val recordedBy: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "vehicleId" to vehicleId,
            "vehicleName" to vehicleName,
            "category" to category,
            "type" to type,
            "amount" to amount,
            "date" to date,
            "notes" to notes,
            "driverName" to driverName,
            "fuelLiters" to fuelLiters,
            "rentDays" to rentDays,
            "recordedBy" to recordedBy,
            "createdAt" to createdAt
        )
    }

    companion object {
        fun fromMap(map: Map<String, Any?>): Transaction {
            return Transaction(
                id = map["id"] as? String ?: "",
                vehicleId = map["vehicleId"] as? String ?: "",
                vehicleName = map["vehicleName"] as? String ?: "",
                category = map["category"] as? String ?: "cng",
                type = map["type"] as? String ?: "daily_rent",
                amount = (map["amount"] as? Number)?.toDouble() ?: 0.0,
                date = map["date"] as? String ?: "",
                notes = map["notes"] as? String ?: "",
                driverName = map["driverName"] as? String ?: "",
                fuelLiters = (map["fuelLiters"] as? Number)?.toDouble() ?: 0.0,
                rentDays = (map["rentDays"] as? Number)?.toInt() ?: 1,
                recordedBy = map["recordedBy"] as? String ?: "",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
