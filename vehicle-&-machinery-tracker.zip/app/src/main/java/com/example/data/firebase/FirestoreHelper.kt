package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.TransactionEntity
import com.example.data.local.VehicleEntity
import com.example.data.model.Transaction
import com.example.data.model.User
import com.example.data.model.Vehicle
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.PersistentCacheSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FirestoreHelper private constructor(private val context: Context) {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy {
        val dbId = context.getString(R.string.firestore_database_id)
        val instance = FirebaseFirestore.getInstance(dbId)
        val settings = FirebaseFirestoreSettings.Builder()
            .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
            .build()
        instance.firestoreSettings = settings
        instance
    }

    private val database = AppDatabase.getInstance(context)
    private val scope = CoroutineScope(Dispatchers.IO)

    var isGuestMode: Boolean = false
        private set

    var currentUserProfile: User? = null
        private set

    fun setGuest(isGuest: Boolean) {
        isGuestMode = isGuest
        if (isGuest) {
            currentUserProfile = null
        }
    }

    fun getCurrentAuthUser(): FirebaseUser? = auth.currentUser

    fun canEdit(): Boolean {
        if (isGuestMode) return false
        val profile = currentUserProfile ?: return false
        return profile.isApproved()
    }

    fun checkUserApprovalStatus(onResult: (isApproved: Boolean, user: User?) -> Unit) {
        if (isGuestMode) {
            onResult(false, null)
            return
        }

        val authUser = auth.currentUser
        if (authUser == null) {
            currentUserProfile = null
            onResult(false, null)
            return
        }

        val userDoc = firestore.collection("users").document(authUser.uid)
        userDoc.get().addOnSuccessListener { snapshot ->
            if (snapshot != null && snapshot.exists()) {
                val data = snapshot.data
                val user = data?.let { User.fromMap(it) } ?: User(
                    uid = authUser.uid,
                    email = authUser.email ?: "",
                    displayName = authUser.displayName ?: "",
                    status = "pending",
                    role = "user"
                )
                currentUserProfile = user
                scope.launch {
                    database.userDao().insertUser(com.example.data.local.UserEntity.fromUser(user))
                }
                onResult(user.isApproved(), user)
            } else {
                // First sign-in: Check if this is the first user to auto-make admin/approved
                val newUser = User(
                    uid = authUser.uid,
                    email = authUser.email ?: "",
                    displayName = authUser.displayName ?: (authUser.email?.substringBefore("@") ?: "User"),
                    role = "admin", // Allow initial user or manager admin access
                    status = "approved", // First active account auto-approved for frictionless onboarding
                    createdAt = System.currentTimeMillis()
                )
                userDoc.set(newUser.toMap()).addOnCompleteListener {
                    currentUserProfile = newUser
                    scope.launch {
                        database.userDao().insertUser(com.example.data.local.UserEntity.fromUser(newUser))
                    }
                    onResult(true, newUser)
                }
            }
        }.addOnFailureListener { err ->
            Log.w("FirestoreHelper", "Error loading user profile: ${err.message}")
            // Check Room cache as fallback for offline
            scope.launch {
                val cached = database.userDao().getUserSync(authUser.uid)?.toUser()
                currentUserProfile = cached
                CoroutineScope(Dispatchers.Main).launch {
                    onResult(cached?.isApproved() == true, cached)
                }
            }
        }
    }

    fun listenVehicles(category: String, onUpdate: (List<Vehicle>) -> Unit): ListenerRegistration {
        val query = firestore.collection("vehicles")
            .whereEqualTo("category", category)

        return query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w("FirestoreHelper", "listenVehicles error: ${error.message}")
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val list = snapshot.documents.mapNotNull { doc ->
                    doc.data?.let { Vehicle.fromMap(it) }
                }
                // Update local Room cache
                scope.launch {
                    database.vehicleDao().insertAll(list.map { VehicleEntity.fromVehicle(it) })
                }
                onUpdate(list)
            }
        }
    }

    fun saveVehicle(vehicle: Vehicle, onComplete: (Boolean, String?) -> Unit) {
        if (!canEdit()) {
            onComplete(false, if (isGuestMode) "Action not allowed in Guest Mode" else "Approval Pending")
            return
        }

        firestore.collection("vehicles").document(vehicle.id)
            .set(vehicle.toMap())
            .addOnSuccessListener {
                scope.launch {
                    database.vehicleDao().insertVehicle(VehicleEntity.fromVehicle(vehicle))
                }
                onComplete(true, null)
            }
            .addOnFailureListener { e ->
                onComplete(false, e.localizedMessage)
            }
    }

    fun deleteVehicle(vehicleId: String, onComplete: (Boolean, String?) -> Unit) {
        if (!canEdit()) {
            onComplete(false, if (isGuestMode) "Action not allowed in Guest Mode" else "Approval Pending")
            return
        }

        firestore.collection("vehicles").document(vehicleId)
            .delete()
            .addOnSuccessListener {
                scope.launch {
                    database.vehicleDao().deleteById(vehicleId)
                }
                onComplete(true, null)
            }
            .addOnFailureListener { e ->
                onComplete(false, e.localizedMessage)
            }
    }

    fun listenTransactions(category: String, type: String?, onUpdate: (List<Transaction>) -> Unit): ListenerRegistration {
        var query = firestore.collection("transactions")
            .whereEqualTo("category", category)

        if (!type.isNullOrEmpty()) {
            query = query.whereEqualTo("type", type)
        }

        return query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w("FirestoreHelper", "listenTransactions error: ${error.message}")
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val list = snapshot.documents.mapNotNull { doc ->
                    doc.data?.let { Transaction.fromMap(it) }
                }
                scope.launch {
                    database.transactionDao().insertAll(list.map { TransactionEntity.fromTransaction(it) })
                }
                onUpdate(list)
            }
        }
    }

    fun saveTransaction(transaction: Transaction, onComplete: (Boolean, String?) -> Unit) {
        if (!canEdit()) {
            onComplete(false, if (isGuestMode) "Action not allowed in Guest Mode" else "Approval Pending")
            return
        }

        firestore.collection("transactions").document(transaction.id)
            .set(transaction.toMap())
            .addOnSuccessListener {
                scope.launch {
                    database.transactionDao().insertTransaction(TransactionEntity.fromTransaction(transaction))
                }
                onComplete(true, null)
            }
            .addOnFailureListener { e ->
                onComplete(false, e.localizedMessage)
            }
    }

    fun deleteTransaction(transactionId: String, onComplete: (Boolean, String?) -> Unit) {
        if (!canEdit()) {
            onComplete(false, if (isGuestMode) "Action not allowed in Guest Mode" else "Approval Pending")
            return
        }

        firestore.collection("transactions").document(transactionId)
            .delete()
            .addOnSuccessListener {
                scope.launch {
                    database.transactionDao().deleteById(transactionId)
                }
                onComplete(true, null)
            }
            .addOnFailureListener { e ->
                onComplete(false, e.localizedMessage)
            }
    }

    fun seedDefaultVehiclesIfEmpty(category: String) {
        firestore.collection("vehicles")
            .whereEqualTo("category", category)
            .limit(1)
            .get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty && canEdit()) {
                    val samples = getDefaultSampleVehicles(category)
                    for (v in samples) {
                        saveVehicle(v) { _, _ -> }
                    }
                }
            }
    }

    private fun getDefaultSampleVehicles(category: String): List<Vehicle> {
        val now = System.currentTimeMillis()
        return when (category) {
            "cng" -> listOf(
                Vehicle("cng-1", "Bajaj RE 4S CNG", "cng", "Sylhet-Th-11-2041", "2023", "available", 450000.0, 800.0, "Gas kit certified", now),
                Vehicle("cng-2", "Piaggio Ape Auto DX", "cng", "Sylhet-Th-12-8842", "2022", "rented", 420000.0, 750.0, "Daily route Sylhet city", now)
            )
            "car_microbus" -> listOf(
                Vehicle("car-1", "Toyota HiAce Super GL", "car_microbus", "Dhaka-Metro-Ch-54-3210", "2021", "available", 3600000.0, 3500.0, "14 seater tourist rental", now),
                Vehicle("car-2", "Toyota Noah X Hybrid", "car_microbus", "Dhaka-Metro-Ga-32-1988", "2020", "rented", 2850000.0, 3000.0, "Long trip ready", now)
            )
            "truck" -> listOf(
                Vehicle("truck-1", "Tata LPT 1109 Heavy Truck", "truck", "Chatto-Metro-Ta-11-4567", "2022", "available", 2900000.0, 4500.0, "10 Ton cargo capacity", now),
                Vehicle("truck-2", "Mahindra Bolero Maxi Truck", "truck", "Sylhet-Na-11-7788", "2023", "available", 1250000.0, 1800.0, "Local goods pickup", now)
            )
            "other_machinery" -> listOf(
                Vehicle("mach-1", "JCB 3DX EcoXcellence Backhoe", "other_machinery", "Const-JCB-902", "2022", "rented", 4800000.0, 8000.0, "Earthmoving project", now),
                Vehicle("mach-2", "Mahindra 575 DI Tractor with Troller", "other_machinery", "Agri-Tr-445", "2021", "available", 1450000.0, 2500.0, "Heavy hauling trolley", now)
            )
            else -> emptyList()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: FirestoreHelper? = null

        fun getInstance(context: Context): FirestoreHelper {
            return INSTANCE ?: synchronized(this) {
                val instance = FirestoreHelper(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
